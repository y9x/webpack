'use strict';

var { keybinds, utils, store } = require('../consts'),
	DataStore = require('../../datastore'),
	PanelDraggable = require('../paneldraggable'),
	Control = require('./control'),
	clone_obj = obj => JSON.parse(JSON.stringify(obj)),
	assign_deep = (target, ...objects) => {
		for(let ind in objects)for(let key in objects[ind]){
			if(typeof objects[ind][key] == 'object' && objects[ind][key] != null && key in target)assign_deep(target[key], objects[ind][key]);
			else if(typeof target == 'object' && target != null)Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(objects[ind], key))
		}
		
		return target;
	};

class Section {
	constructor(name, panel){
		this.panel = panel;
		
		this.node = utils.add_ele('section', this.panel.sections_con);
		
		this.name = name;
		
		this.controls = new Set();
		
		utils.add_ele('div', this.panel.sidebar_con, { className: 'open-section', textContent: this.name }).addEventListener('click', () => this.interact());
		
		this.create_ui();
		
		this.hide();
	}
	create_ui(){}
	interact(){
		this.show();
		
		for(let section of this.panel.sections)if(section != this)section.hide();
	}
	get visible(){
		return !this.node.classList.contains('hidden');
	}
	update(){
		for(let control of this.controls)try{
			control.update();
		}catch(err){
			console.error(err);
		}
	}
	show(dont_save){
		this.node.classList.remove('hidden');
		this.update();
		
		this.panel.config.section = this.name;
		if(!dont_save)this.panel.save_config();
	}
	hide(){
		this.node.classList.add('hidden');
	}
};

class ControlSection extends Section {
	static id = 'control';
	add_control(name, data){
		for(let type of Control.Types)if(type.id == data.type)return this.controls.add(new type(name, data, this));
		throw new TypeError('Unknown type: ' + data.type);
	}
};

class FunctionSection extends Section {
	static id = 'function';
	interact(){
		this.data.value();
	}
};

Section.Types = [
	ControlSection,
	FunctionSection,
];

class Config extends PanelDraggable {
	constructor(data, key, store = new DataStore()){
		super(data, 'config');	
		
		this.store = store;
		
		this.config_key = key;
		
		this.presets = new Map();
		
		this.sections = new Set();
		
		this.title = this.listen_dragging(utils.add_ele('div', this.node, { textContent: data.title, className: 'title' }));
		
		utils.add_ele('div', this.title, { className: 'version', textContent: 'v' + data.version });
		
		this.sections_con = utils.add_ele('div', this.node, { className: 'sections' });
		this.sidebar_con = utils.add_ele('div', this.sections_con, { className: 'sidebar' });
		
		keybinds.push(this.toggle_bind = {
			code: [ 'F1' ],
			interact: () => {
				// this.save_config();
				
				if(this.visible)this.hide();
				else this.show();
			},
		});
		
		this.footer = utils.add_ele('footer', this.node);
		
		this.apply_bounds();
	}
	get default_section(){
		var first,
			active_config;
		
		for(let section of this.sections){
			if(!first)first = section;
			if(section.visible)return section;
			if(section.name == this.config.section)active_config = section;
		}
		
		return active_config || first;
	}
	update(start){
		this.apply_bounds();
		
		this.default_section.show(start);
		
		for(let section of this.sections)if(section != this.default_section)section.hide();
		
		this.toggle_bind.code = [ 'F1', this.config.binds.toggle ];
		
		var bind = this.toggle_bind.code.map(utils.string_key).map(x => '[' + x + ']').join(' or ');
		
		this.footer.textContent = `Press ${bind} to toggle`;
	}
	add_tab(name){
		var tab = new ControlSection(name, this);
		
		this.sections.add(tab);
		
		return tab;
	}
	add_preset(label, value){
		this.presets.set(label, value);
	}
	async insert_config(data, save = false){
		this.config = utils.assign_deep(utils.clone_obj(this.presets.get('Default')), data);
		
		if(save)await this.save_config();
		
		this.update(true);
	}
	async load_preset(preset){
		if(!this.presets.has(preset))throw new Error('Invalid preset:', preset);
		
		this.insert_config(this.presets.get(preset), true);
	}
	async save_config(){
		await this.store.set(this.config_key, this.config);
	}
	async load_config(){
		this.insert_config(await this.store.get(this.config_key, 'object'));
		
		setTimeout(() => {
			this.pos = { x: 1, y: this.center_side('height') };
			this.apply_bounds();
			this.load_ui_data();
		});
	}
};

module.exports = Config;