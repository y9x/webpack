'use strict';

var { keybinds, utils, frame, content } = require('./consts.js'),
	Panel = require('./panel'),
	update_pe = event => {
		for(let panel of Panel.panels){
			if(!panel.visible)continue;
			
			let rect = panel.node.getBoundingClientRect(),
				hover = event.clientX >= rect.x && event.clientY >= rect.y && (event.clientX - rect.x) <= rect.width && (event.clientY - rect.y) <= rect.height;
			
			if(hover)return content.style['pointer-events'] = 'all';
		}
		
		content.style['pointer-events'] = 'none';
		
		for(let panel of Panel.panels)panel.blur();
	},
	resize_canvas = () => {
		exports.canvas.width = window.innerWidth;
		exports.canvas.height = window.innerHeight;
	};

new FontFace('inconsolata', 'url("https://y9x.github.io/webpack/libs/ui/inconsolata.woff2")').load().then(font => document.fonts.add(font));

window.addEventListener('mousemove', update_pe, { passive: true });
window.addEventListener('mousedown', update_pe, { passive: true });
window.addEventListener('mouseup', update_pe, { passive: true });

exports.canvas = utils.add_ele('canvas', frame);

exports.ctx = exports.canvas.getContext('2d', { alpha: true });

resize_canvas();

window.addEventListener('keydown', event => {
	if(event.repeat || document.activeElement && ['TEXTAREA', 'INPUT'].includes(document.activeElement.tagName))return;
	
	// some(keycode => typeof keycode == 'string' && [ keycode, keycode.replace('Digit', 'Numpad') ]
	for(let keybind of keybinds)if(keybind.code.includes(event.code)){
		event.preventDefault();
		keybind.interact();
	}
});

window.addEventListener('contextmenu', event => !(event.target != null && event.target instanceof HTMLTextAreaElement) && event.preventDefault());

window.addEventListener('resize', resize_canvas);

utils.add_ele('style', frame, { textContent: require('./ui.css') });

var actions = require('./actions');

exports.alert = actions.alert;
exports.prompt = actions.prompt;
exports.options = actions.options;
exports.frame = frame;
exports.keybinds = keybinds;
exports.Loading = require('./loading');
exports.Config = require('./config/');
exports.Editor = require('./editor/');